// Firm was used in place of Q1 since it was the public class with the public method as in the UML diagram
// The payday is calculated by multiplying the rate with the number of hours and adding it to the commission rate multiplied by the total sales


class Staff {
	private StaffMember[] staffList;
	
	 Staff(){
		 staffList = new StaffMember[8];
		 staffList[0] = new Volunteer ("Kwabena", "EB-0012-0007", "0204958671");
		 staffList[1] = new Volunteer ("Jo", "EB-0012-0008", "0204958644");
		 staffList[2] = new Employee ("Kwasi", "EB-0012-0005", "0204958672", "45688", 8.9);
		 staffList[3] = new Employee ("Kofi", "EB-0012-0003", "0204958674", "78954", 11.5);
		 staffList[4] = new Executive ("Kwame", "EB-0012-0004", "0204958673", "785489", 12.5);
		 staffList[5] = new Hourly ("Kojo", "EB-0012-0006", "0204958672", "76466", 1.5);
		 staffList[6] = new Commission ("Ama", "EB-0012-0009", "0204958670", "234567", 6.25, 0.2);
		 staffList[7] = new Commission ("Prince ", "EB-0012-0012", "0240490102", "2198", 9.75, 0.15);
		 
		 ((Commission)staffList[6]).addHours(35);
		 ((Commission)staffList[6]).addSales(400);
		 ((Commission)staffList[7]).addHours(40);
		 ((Commission)staffList[7]).addSales(950);
	 }
	
	public void payday () {
		for (int i=0; i< staffList.length; i++) {
			System.out.println(staffList[i]);
			System.out.println("Paid: "+ staffList[i].pay());
		}
		
	}
}

abstract class StaffMember{
	protected String name;
	protected String address;
	protected String phone;
	
	StaffMember(String name, String address, String phone){
		this.name = name;
		this.address = address;
		this.phone = phone;
	}
	
	public String toString() {
		return "Name: " + name + " Address: " +address + " Phone Number: "+phone ;
	}
	
	public double pay() {
		return 0;
	}
	
	
}

class Volunteer extends StaffMember{

	Volunteer(String vname, String vaddress, String vphone) {
		super(vname, vaddress, vphone);
		
	}
	public double pay() {
		return 0;
	}
	
}


class Employee extends StaffMember{
	
	protected String socialSecurityNumber;
	protected double payRate;

	Employee(String ename, String eaddress, String ephone, String soSecurityNumber, double rate) {
		super(ename, eaddress, ephone);
		socialSecurityNumber = soSecurityNumber;
		payRate = rate;
		
	}
	
	public String toString() {
		return super.toString() + " Social Security Number is: " + socialSecurityNumber + " Pay Rate is: "+payRate;
	}
	

	
	public double pay() {
		return 0;
	}
	
}


class Executive extends Employee{
	private double bonus;

	Executive(String exname, String exaddress, String exphone, String soSecurityNumber, double rate) {
		super(exname, exaddress, exphone, soSecurityNumber, rate);
	}
	
	public double awardBonus (double exbonus) {
		bonus = exbonus;
		return bonus;
	}
	
	public double pay() {
		return payRate;
	}
	
}


class Hourly extends Employee{
	private int hoursWorked;

	Hourly(String ename, String eaddress, String ephone, String soSecurityNumber, double rate) {
		super(ename, eaddress, ephone, soSecurityNumber, rate);

	}
	
	public void addHours(int moreHours) {
		hoursWorked += moreHours;
	}
	
	public double pay() {
		return hoursWorked*payRate;
	}
	
	public String toString() {
		return super.toString();
	}
	
}

class Commission extends Hourly{
	double totalSales = 0;
	double commissionRate;

	Commission(String ename, String eaddress, String ephone, String soSecurityNumber, double rate, double coRate) {
		super(ename, eaddress, ephone, soSecurityNumber, rate);
		commissionRate = coRate;
		
	}
	
	public void addSales(double totalSale) {
		totalSales += totalSale;
		
	}
	
	public double pay() {
		return super.pay() + totalSales*commissionRate;
	}
	
}



public class Firm {

	public static void main(String[] args) {
		Staff s = new Staff();
		s.payday();

	}

}
